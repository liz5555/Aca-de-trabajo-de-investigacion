<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Carga automática de clases (Composer)
require_once __DIR__ . '/../vendor/autoload.php'; // Carga automática de PHPMailer

function enviarCorreo($destinatario, $asunto, $mensajePlano) {
    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'leisdylisbenmayorsuarez@gmail.com';  // TU CORREO
        $mail->Password   = 'ceiuoogvibllooyr';                    // CONTRASEÑA DE APLICACIÓN
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        // Remitente y destinatario
        $mail->setFrom('leisdylisbenmayorsuarez@gmail.com', 'Sistema de Citas');
        $mail->addAddress($destinatario);

        // Cuerpo del mensaje (en HTML)
        $mensajeHtml = "
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
                .card { background-color: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 20px; }
                .titulo { color: #0a6ebd; font-size: 20px; margin-bottom: 10px; }
                .mensaje { font-size: 16px; color: #333; }
            </style>
        </head>
        <body>
            <div class='card'>
                <div class='titulo'>Confirmación de Cita Médica</div>
                <div class='mensaje'>
                    $mensajePlano
                </div>
            </div>
        </body>
        </html>";

        // Configurar mensaje
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body    = $mensajeHtml;

        // Enviar
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("❌ Error al enviar correo: {$mail->ErrorInfo}");
        return false;
    }
}
?>

