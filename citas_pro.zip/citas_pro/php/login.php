<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    if ($conn) {
        $stmt = $conn->prepare("SELECT * FROM usuarios WHERE correo = ? AND contrasena = ?");
        $stmt->bind_param("ss", $correo, $contrasena);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows == 1) {
            $usuario = $resultado->fetch_assoc();
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario'] = $usuario;
            $_SESSION['rol'] = $usuario['rol'];

            if ($usuario['rol'] === 'admin') {
                header("Location: panel_admin.php");
            } else {
                header("Location: panel_paciente.php");
            }
            exit();
        } else {
            echo "Correo o contraseña incorrectos.";
        }
    } else {
        echo "Error en la conexión a la base de datos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
   
    <link rel="stylesheet" href="css/estilo.css">

</head>
<body>
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <form action="tu_controlador.php" method="POST">
            <label for="correo">Correo</label>
            <input type="text" name="correo" id="correo" required>

            <label for="clave">Contraseña</label>
            <input type="password" name="clave" id="clave" required>

            <input type="submit" value="Ingresar">
        </form>
    </div>
</body>
</html>