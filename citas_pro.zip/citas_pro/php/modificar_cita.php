<?php
include("conexion.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Obtener la cita
    $query = "SELECT * FROM citas WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $cita = $resultado->fetch_assoc();
} else {
    echo "ID no válido.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Cita</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <div class="modificar-cita-container">
        <h2>Modificar Cita</h2>
        <form action="guardar_modificacion.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $cita['id']; ?>">

            <div class="campo-formulario">
                <label for="fecha">Fecha:</label>
                <input type="date" name="fecha" value="<?php echo $cita['fecha']; ?>" required>
            </div>

            <div class="campo-formulario">
                <label for="hora">Hora:</label>
                <input type="time" name="hora" value="<?php echo $cita['hora']; ?>" required>
            </div>

            <div class="campo-formulario">
                <label for="estado">Estado:</label>
                <select name="estado">
                    <option value="pendiente" <?php if($cita['estado'] == 'pendiente') echo 'selected'; ?>>Pendiente</option>
                    <option value="asistida" <?php if($cita['estado'] == 'asistida') echo 'selected'; ?>>Asistida</option>
                    <option value="cancelada" <?php if($cita['estado'] == 'cancelada') echo 'selected'; ?>>Cancelada</option>
                    <option value="no asistió" <?php if($cita['estado'] == 'no asistió') echo 'selected'; ?>>No asistió</option>
                </select>
            </div>

            <input type="submit" value="Guardar Cambios">
        </form>
    </div>
</body>
</html>
