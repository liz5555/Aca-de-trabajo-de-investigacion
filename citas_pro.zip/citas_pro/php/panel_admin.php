<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

include("conexion.php");

// Consulta de citas médicas
$query = "SELECT 
            c.id, u.nombre AS paciente, m.nombre AS medico, s.nombre AS servicio, 
            c.fecha, c.hora, c.estado
          FROM citas c
          INNER JOIN usuarios u ON c.usuario_id = u.id
          INNER JOIN medicos m ON c.medico_id = m.id
          INNER JOIN servicios s ON c.servicio_id = s.id";

$resultado = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Medico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
      
    body {
        background-color:rgb(4, 81, 163);
        color: #ffffff;
        font-family: 'Segoe UI', sans-serif;
        font-size: 14px;
    }

    h1, h2 {
        text-align: center;
        margin-top: 15px;
        font-size: 24px;
    }

    table {
        width: 80%;
        margin: 20px auto;
        background-color:rgb(9, 38, 66);
        border-collapse: collapse;
        font-size: 13px;
    }

    th, td {
        padding: 8px 10px;
        border: 1px solid #ffffff;
        text-align: center;
    }

    th {
        background-color:rgb(16, 91, 184);
        font-size: 14px;
    }

    a {
        color: #90e0ef;
        text-decoration: none;
        margin: 0 3px;
    }

    a:hover {
        text-decoration: underline;
    }

    .btn-pdf {
        display: block;
        text-align: right;
        width: 80%;
        margin: 10px auto;
    }

    .btn-pdf a {
        color:rgb(212, 209, 7);
        font-weight: bold;
    }

    .btn-pdf a:hover {
        color: #ffffff;
    }

    </style>
</head>
<body>

    <h1>Panel del Medico</h1>
    <h2>Citas Médicas Generadas</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Paciente</th>
            <th>Médico</th>
            <th>Servicio</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>

        <?php while($row = $resultado->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['paciente']; ?></td>
                <td><?= $row['medico']; ?></td>
                <td><?= $row['servicio']; ?></td>
                <td><?= $row['fecha']; ?></td>
                <td><?= $row['hora']; ?></td>
                <td><?= $row['estado']; ?></td>
                <td>
                    <a href="modificar_cita.php?id=<?= $row['id']; ?>">✏️ Modificar</a> |
                    <a href="cancelar_cita.php?id=<?= $row['id']; ?>" onclick="return confirm('¿Cancelar esta cita?')">❌ Cancelar</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <div class="btn-pdf">
        <a href="reporte_pdf.php" target="_blank">📄 Descargar Reporte PDF</a>
    </div>

</body>
</html>
