<?php
include("conexion.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "UPDATE citas SET estado = 'cancelada' WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: panel_admin.php");
    exit();
} else {
    echo "ID no válido.";
}
?>