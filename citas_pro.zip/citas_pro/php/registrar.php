<?php
include('conexion.php');

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];
$rol = $_POST['rol'];

$query = "INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES ('$nombre', '$correo', '$contrasena', '$rol')";

if (mysqli_query($conexion, $query)) {
    echo "<script>alert('Registro exitoso.'); window.location.href='login.php';</script>";
} else {
    echo "Error al registrar: " . mysqli_error($conexion);
}
?>