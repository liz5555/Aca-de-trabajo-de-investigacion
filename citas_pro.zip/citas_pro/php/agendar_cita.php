<?php
session_start();
include 'conexion.php';

// Verifica que el usuario haya iniciado sesión y sea paciente
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'paciente') {
    echo "Acceso no autorizado.";
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$mensaje = "";

// Obtener médicos
$medicos = $conn->query("SELECT id, nombre FROM medicos");

// Obtener servicios
$servicios = $conn->query("SELECT id, nombre FROM servicios");

// Procesar formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $medico_id = $_POST['medico_id'];
    $servicio_id = $_POST['servicio_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];

    // Validación mínima
    if ($medico_id && $servicio_id && $fecha && $hora) {
        $stmt = $conn->prepare("INSERT INTO citas (usuario_id, medico_id, servicio_id, fecha, hora, estado) VALUES (?, ?, ?, ?, ?, 'pendiente')");
        $stmt->bind_param("iiiss", $usuario_id, $medico_id, $servicio_id, $fecha, $hora);
        if ($stmt->execute()) {
            $mensaje = "<div class='alert alert-success'>✅ Cita agendada correctamente.</div>";
        } else {
            $mensaje = "<div class='alert alert-danger'>❌ Error al agendar la cita.</div>";
        }
    } else {
        $mensaje = "<div class='alert alert-warning'>⚠️ Por favor completa todos los campos.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agendar Cita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="text-center mb-4">Agendar Nueva Cita</h2>

    <?= $mensaje ?>

    <form method="POST" class="card p-4 shadow">
        <div class="mb-3">
            <label for="medico_id" class="form-label">Médico</label>
            <select name="medico_id" class="form-select" required>
                <option value="">Seleccione un médico</option>
                <?php foreach ($medicos as $medico): ?>
                    <option value="<?= $medico['id'] ?>"><?= htmlspecialchars($medico['nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="servicio_id" class="form-label">Servicio</label>
            <select name="servicio_id" class="form-select" required>
                <option value="">Seleccione un servicio</option>
                <?php foreach ($servicios as $servicio): ?>
                    <option value="<?= $servicio['id'] ?>"><?= htmlspecialchars($servicio['nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="fecha" class="form-label">Fecha</label>
            <input type="date" name="fecha" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="hora" class="form-label">Hora</label>
            <input type="time" name="hora" class="form-control" required>
        </div>

        <div class="d-flex justify-content-between">
            <a href="panel_paciente.php" class="btn btn-secondary">⬅ Volver</a>
            <button type="submit" class="btn btn-success">Agendar Cita</button>
        </div>
    </form>
</div>
</body>
</html>