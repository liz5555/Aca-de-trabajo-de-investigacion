<?php
require '../vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

include 'conexion.php';

// Consulta de todas las citas
$sql = "SELECT c.fecha, c.hora, c.estado, p.nombre AS paciente, m.nombre AS medico, s.nombre AS servicio
        FROM citas c
        JOIN usuarios p ON c.paciente_id = p.id
        JOIN medicos m ON c.medico_id = m.id
        JOIN servicios s ON c.servicio_id = s.id";
$result = $conn->query($sql);

// Generar el contenido HTML del reporte
$html = '<h2 style="text-align:center;">Reporte General de Citas Médicas</h2>';
$html .= '<table border="1" cellpadding="8" cellspacing="0" width="100%">
            <thead>
            <tr style="background-color:#eee;">
                <th>Paciente</th>
                <th>Médico</th>
                <th>Servicio</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Estado</th>
            </tr>
            </thead><tbody>';

while($row = $result->fetch_assoc()) {
    $html .= '<tr>
                <td>' . $row['paciente'] . '</td>
                <td>' . $row['medico'] . '</td>
                <td>' . $row['servicio'] . '</td>
                <td>' . $row['fecha'] . '</td>
                <td>' . $row['hora'] . '</td>
                <td>' . ucfirst($row['estado']) . '</td>
              </tr>';
}
$html .= '</tbody></table>';

// Configuración de Dompdf
$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape'); // horizontal
$dompdf->render();

// Descargar en el navegador
$dompdf->stream("reporte_citas.pdf", ["Attachment" => false]);
exit;
?>