<?php
include("conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $estado = $_POST['estado'];

    $query = "UPDATE citas SET fecha = ?, hora = ?, estado = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $fecha, $hora, $estado, $id);
    $stmt->execute();

    header("Location: panel_admin.php");
    exit();
} else {
    echo "Acceso no permitido.";
}
?>