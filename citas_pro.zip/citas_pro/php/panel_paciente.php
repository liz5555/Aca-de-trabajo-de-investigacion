<?php
session_start();
include 'conexion.php';
include_once 'enviar_correo.php'; // debe cargarse antes de llamar la función

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'paciente') {
    echo "Acceso no autorizado. Por favor inicia sesión.";
    exit;
}

$usuario = $_SESSION['usuario'];
$usuario_id = $_SESSION['usuario_id'];
$nombre = isset($usuario['nombre']) ? htmlspecialchars($usuario['nombre']) : 'Paciente';
$mensaje = "";

// Agendar nueva cita
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medico_id = $_POST['medico_id'];
    $servicio_id = $_POST['servicio_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];

    $stmt = $conn->prepare("INSERT INTO citas (paciente_id, medico_id, servicio_id, fecha, hora, estado) VALUES (?, ?, ?, ?, ?, 'pendiente')");
    $stmt->bind_param("iiiss", $usuario_id, $medico_id, $servicio_id, $fecha, $hora);

    if ($stmt->execute()) {
        $correo_paciente = isset($usuario['correo']) ? $usuario['correo'] : '';
        $nombre_paciente = isset($usuario['nombre']) ? $usuario['nombre'] : 'Paciente';

        $asunto = "Confirmación de cita médica";
        $mensaje_correo = "Hola $nombre_paciente,\n\nTu cita médica ha sido agendada para el día $fecha a las $hora.\n\nGracias por usar nuestro sistema.";

        if (!empty($correo_paciente) && enviarCorreo($correo_paciente, $asunto, $mensaje_correo)) {
            $mensaje = "<div class='alert alert-success'>Cita agendada correctamente y notificación enviada.</div>";
        } else {
            $mensaje = "<div class='alert alert-warning'>Cita agendada, pero no se pudo enviar el correo.</div>";
        }
    } else {
        $mensaje = "<div class='alert alert-danger'>Error al agendar la cita.</div>";
    }
}

// Consultar citas del paciente
$citas = $conn->prepare("SELECT c.*, m.nombre AS medico, s.nombre AS servicio 
                         FROM citas c 
                         JOIN medicos m ON c.medico_id = m.id 
                         JOIN servicios s ON c.servicio_id = s.id 
                         WHERE c.paciente_id = ?");
$citas->bind_param("i", $usuario_id);
$citas->execute();
$resultado = $citas->get_result();

$medicos = $conn->query("SELECT * FROM medicos");
$servicios = $conn->query("SELECT * FROM servicios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Paciente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
      
    body {
        background-color:rgb(4, 81, 163);
        color: #ffffff;
        font-family: 'Segoe UI', sans-serif;
        font-size: 14px;
    }

    h1, h2 {
        text-align: center;
        margin-top: 15px;
        font-size: 24px;
    }

    table {
        width: 80%;
        margin: 20px auto;
        background-color:rgb(9, 38, 66);
        border-collapse: collapse;
        font-size: 13px;
    }

    th, td {
        padding: 8px 10px;
        border: 1px solid #ffffff;
        text-align: center;
    }

    th {
        background-color:rgb(16, 91, 184);
        font-size: 14px;
    }

    a {
        color: #90e0ef;
        text-decoration: none;
        margin: 0 3px;
    }

    a:hover {
        text-decoration: underline;
    }

    .btn-pdf {
        display: block;
        text-align: right;
        width: 80%;
        margin: 10px auto;
    }

    .btn-pdf a {
        color:rgb(212, 209, 7);
        font-weight: bold;
    }

    .btn-pdf a:hover {
        color: #ffffff;
    }

    </style>
</head>

<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4 text-center">Bienvenido, <?= htmlspecialchars($nombre) ?> (Paciente)</h2>

    <?= $mensaje ?>

    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">Tus Citas Médicas</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Estado</th>
                    <th>Médico</th>
                    <th>Servicio</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($resultado && $resultado->num_rows > 0): ?>
                    <?php while($cita = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?= $cita['fecha'] ?></td>
                            <td><?= $cita['hora'] ?></td>
                            <td><?= ucfirst($cita['estado']) ?></td>
                            <td><?= $cita['medico'] ?></td>
                            <td><?= $cita['servicio'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">No tienes citas registradas.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-header bg-success text-white">Agendar Nueva Cita</div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label for="medico_id" class="form-label">Médico</label>
                    <select name="medico_id" class="form-select" required>
                        <option value="">Seleccione un médico</option>
                        <?php while($medico = $medicos->fetch_assoc()): ?>
                            <option value="<?= $medico['id'] ?>"><?= $medico['nombre'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="servicio_id" class="form-label">Servicio</label>
                    <select name="servicio_id" class="form-select" required>
                        <option value="">Seleccione un servicio</option>
                        <?php while($servicio = $servicios->fetch_assoc()): ?>
                            <option value="<?= $servicio['id'] ?>"><?= $servicio['nombre'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="fecha" class="form-label">Fecha</label>
                    <input type="date" name="fecha" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="hora" class="form-label">Hora</label>
                    <input type="time" name="hora" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-success">Agendar Cita</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
